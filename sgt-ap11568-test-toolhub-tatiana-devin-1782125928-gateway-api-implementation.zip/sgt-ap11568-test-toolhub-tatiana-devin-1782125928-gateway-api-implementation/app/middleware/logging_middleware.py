import logging
import time
import uuid

from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint

logger = logging.getLogger(__name__)


class RequestLoggingMiddleware(BaseHTTPMiddleware):
    async def dispatch(
        self, request: Request, call_next: RequestResponseEndpoint
    ) -> Response:
        correlation_id = getattr(request.state, "correlation_id", None)
        if not correlation_id:
            correlation_id = request.headers.get("X-Request-ID") or str(uuid.uuid4())
            request.state.correlation_id = correlation_id

        start_time = time.time()

        logger.info(
            "Request started",
            extra={
                "correlation_id": correlation_id,
                "method": request.method,
                "path": request.url.path,
                "consumer_id": getattr(request.state, "consumer_id", "unknown"),
            },
        )

        response = await call_next(request)

        duration_ms = (time.time() - start_time) * 1000

        logger.info(
            "Request completed",
            extra={
                "correlation_id": correlation_id,
                "method": request.method,
                "path": request.url.path,
                "status_code": response.status_code,
                "duration_ms": round(duration_ms, 2),
                "consumer_id": getattr(request.state, "consumer_id", "unknown"),
            },
        )

        response.headers["X-Request-ID"] = correlation_id
        return response
