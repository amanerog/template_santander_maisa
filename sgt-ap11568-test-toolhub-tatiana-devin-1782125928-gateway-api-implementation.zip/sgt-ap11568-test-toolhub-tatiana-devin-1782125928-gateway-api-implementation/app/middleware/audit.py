import json
import logging
import time
import uuid
from typing import Optional

from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint

logger = logging.getLogger(__name__)


def _get_langfuse_client(request: Request):
    """Lazy-initialize Langfuse client."""
    if not hasattr(request.app.state, "langfuse_client"):
        try:
            from langfuse import Langfuse

            settings = request.app.state.settings
            request.app.state.langfuse_client = Langfuse(
                public_key=settings.langfuse_public_key,
                secret_key=settings.langfuse_secret_key,
                host=settings.langfuse_host,
            )
        except Exception as e:
            logger.warning(f"Failed to initialize Langfuse client: {e}")
            request.app.state.langfuse_client = None

    return request.app.state.langfuse_client


def _determine_service_name(path: str) -> str:
    if "/openai/" in path:
        if "chat/completions" in path:
            return "chat_completions"
        if "embeddings" in path:
            return "embeddings"
        return "openai_other"
    if "/speech" in path:
        if "transcriptions" in path:
            return "speech_batch_transcription"
        return "speech_to_text"
    return "unknown"


def _extract_deployment_id(path: str) -> Optional[str]:
    parts = path.split("/")
    if "deployments" in parts:
        idx = parts.index("deployments")
        if idx + 1 < len(parts):
            return parts[idx + 1]
    return None


class AuditMiddleware(BaseHTTPMiddleware):
    async def dispatch(
        self, request: Request, call_next: RequestResponseEndpoint
    ) -> Response:
        # Skip auditing for health and docs endpoints
        path = request.url.path
        if path.startswith("/health") or path.startswith("/docs") or path.startswith("/openapi"):
            return await call_next(request)

        correlation_id = request.headers.get("X-Request-ID") or str(uuid.uuid4())
        request.state.correlation_id = correlation_id

        start_time = time.time()

        # Read request body
        request_body = await request.body()
        request_input = None
        content_type = request.headers.get("content-type", "")

        if "application/json" in content_type:
            try:
                request_input = json.loads(request_body)
            except (json.JSONDecodeError, UnicodeDecodeError):
                request_input = {"raw": "non-json-body"}
        elif "audio/" in content_type:
            request_input = {"type": "binary_audio", "size_bytes": len(request_body)}
        else:
            request_input = {"type": content_type, "size_bytes": len(request_body)}

        response = await call_next(request)

        end_time = time.time()
        duration_ms = (end_time - start_time) * 1000

        # Read response body
        response_body_bytes = b""
        async for chunk in response.body_iterator:
            if isinstance(chunk, str):
                response_body_bytes += chunk.encode()
            else:
                response_body_bytes += chunk

        response_output = None
        try:
            response_output = json.loads(response_body_bytes)
        except (json.JSONDecodeError, UnicodeDecodeError):
            response_output = {"type": "non-json", "size_bytes": len(response_body_bytes)}

        # Rebuild response with consumed body
        response = Response(
            content=response_body_bytes,
            status_code=response.status_code,
            headers=dict(response.headers),
            media_type=response.media_type,
        )

        # Send trace to Langfuse (non-blocking)
        try:
            langfuse = _get_langfuse_client(request)
            if langfuse:
                consumer_id = getattr(request.state, "consumer_id", "anonymous")
                settings = request.app.state.settings
                service_name = _determine_service_name(path)
                deployment_id = _extract_deployment_id(path)

                trace = langfuse.trace(
                    id=correlation_id,
                    name=service_name,
                    user_id=consumer_id,
                    input=request_input,
                    output=response_output,
                    metadata={
                        "environment": settings.environment,
                        "deployment_id": deployment_id,
                        "api_version": request.query_params.get("api-version"),
                        "http_method": request.method,
                        "http_status_code": response.status_code,
                        "duration_ms": round(duration_ms, 2),
                        "path": path,
                    },
                    tags=[
                        settings.environment,
                        consumer_id,
                        service_name,
                    ],
                )

                # Create generation span for OpenAI calls with token usage
                if service_name in ("chat_completions", "embeddings") and response_output:
                    usage_data = response_output.get("usage", {}) if isinstance(response_output, dict) else {}
                    level = "ERROR" if response.status_code >= 400 else "DEFAULT"

                    trace.generation(
                        name=f"{service_name}_call",
                        model=deployment_id,
                        input=request_input,
                        output=response_output,
                        start_time=start_time,
                        end_time=end_time,
                        usage={
                            "prompt_tokens": usage_data.get("prompt_tokens"),
                            "completion_tokens": usage_data.get("completion_tokens"),
                            "total_tokens": usage_data.get("total_tokens"),
                        },
                        level=level,
                        status_message=(
                            response_output.get("error", {}).get("message")
                            if isinstance(response_output, dict) and response.status_code >= 400
                            else None
                        ),
                    )
                elif service_name in ("speech_to_text", "speech_batch_transcription"):
                    level = "ERROR" if response.status_code >= 400 else "DEFAULT"
                    trace.span(
                        name=f"{service_name}_call",
                        input=request_input,
                        output=response_output,
                        start_time=start_time,
                        end_time=end_time,
                        level=level,
                    )

        except Exception as e:
            logger.warning(f"Langfuse audit failed (non-blocking): {e}")

        return response
