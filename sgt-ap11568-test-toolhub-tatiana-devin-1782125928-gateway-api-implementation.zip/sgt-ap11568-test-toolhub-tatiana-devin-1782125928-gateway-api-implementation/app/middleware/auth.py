import logging
import time
from typing import Optional

import httpx
import jwt
from fastapi import HTTPException, Request
from jwt import PyJWKClient, ExpiredSignatureError, InvalidTokenError

logger = logging.getLogger(__name__)

_jwks_cache: Optional[dict] = None
_jwks_cache_time: float = 0
_JWKS_CACHE_TTL = 86400  # 24 hours


async def _fetch_jwks(tenant_id: str) -> dict:
    global _jwks_cache, _jwks_cache_time

    now = time.time()
    if _jwks_cache and (now - _jwks_cache_time) < _JWKS_CACHE_TTL:
        return _jwks_cache

    jwks_url = (
        f"https://login.microsoftonline.com/{tenant_id}/discovery/v2.0/keys"
    )
    async with httpx.AsyncClient() as client:
        response = await client.get(jwks_url, timeout=10.0)
        response.raise_for_status()
        _jwks_cache = response.json()
        _jwks_cache_time = now
        return _jwks_cache


def _find_key(jwks: dict, kid: str) -> Optional[dict]:
    for key in jwks.get("keys", []):
        if key.get("kid") == kid:
            return key
    return None


def _build_rsa_public_key(jwk_data: dict):
    """Build an RSA public key from JWK data."""
    from jwt.algorithms import RSAAlgorithm
    import json
    return RSAAlgorithm.from_jwk(json.dumps(jwk_data))


async def validate_token(request: Request) -> dict:
    settings = request.app.state.settings
    tenant_id = settings.entra_tenant_id
    client_id = settings.entra_client_id

    auth_header = request.headers.get("Authorization")
    if not auth_header or not auth_header.startswith("Bearer "):
        raise HTTPException(
            status_code=401,
            detail={
                "type": "https://tools.ietf.org/html/rfc7807",
                "title": "Unauthorized",
                "status": 401,
                "detail": "Missing or invalid Authorization header. Expected: Bearer <token>",
                "instance": str(request.url.path),
            },
        )

    token = auth_header[7:]

    try:
        unverified_header = jwt.get_unverified_header(token)
    except Exception:
        raise HTTPException(
            status_code=401,
            detail={
                "type": "https://tools.ietf.org/html/rfc7807",
                "title": "Unauthorized",
                "status": 401,
                "detail": "Invalid token format",
                "instance": str(request.url.path),
            },
        )

    kid = unverified_header.get("kid")
    if not kid:
        raise HTTPException(
            status_code=401,
            detail={
                "type": "https://tools.ietf.org/html/rfc7807",
                "title": "Unauthorized",
                "status": 401,
                "detail": "Token missing key ID (kid)",
                "instance": str(request.url.path),
            },
        )

    global _jwks_cache, _jwks_cache_time
    jwks = await _fetch_jwks(tenant_id)
    key_data = _find_key(jwks, kid)

    # If key not found, try refreshing JWKS (key rotation)
    if not key_data:
        _jwks_cache = None
        _jwks_cache_time = 0
        jwks = await _fetch_jwks(tenant_id)
        key_data = _find_key(jwks, kid)

    if not key_data:
        raise HTTPException(
            status_code=401,
            detail={
                "type": "https://tools.ietf.org/html/rfc7807",
                "title": "Unauthorized",
                "status": 401,
                "detail": "Token signing key not found",
                "instance": str(request.url.path),
            },
        )

    try:
        public_key = _build_rsa_public_key(key_data)
        payload = jwt.decode(
            token,
            public_key,
            algorithms=["RS256"],
            audience=client_id,
            issuer=f"https://login.microsoftonline.com/{tenant_id}/v2.0",
            options={"verify_nbf": True},
        )
    except ExpiredSignatureError:
        raise HTTPException(
            status_code=401,
            detail={
                "type": "https://tools.ietf.org/html/rfc7807",
                "title": "Unauthorized",
                "status": 401,
                "detail": "Token has expired",
                "instance": str(request.url.path),
            },
        )
    except InvalidTokenError as e:
        raise HTTPException(
            status_code=401,
            detail={
                "type": "https://tools.ietf.org/html/rfc7807",
                "title": "Unauthorized",
                "status": 401,
                "detail": f"Token validation failed: {str(e)}",
                "instance": str(request.url.path),
            },
        )

    consumer_id = payload.get("azp") or payload.get("appid") or payload.get("sub")
    request.state.consumer_id = consumer_id
    request.state.token_claims = payload

    return payload
