import logging

from fastapi import APIRouter, Depends, Request, Response

from app.middleware.auth import validate_token
from app.services.azure_client import AzureClient

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/openai", tags=["Azure OpenAI"])


def _get_azure_client(request: Request) -> AzureClient:
    return AzureClient(
        http_client=request.app.state.http_client,
        settings=request.app.state.settings,
    )


@router.post("/deployments/{deployment_id}/chat/completions")
async def chat_completions(
    deployment_id: str,
    request: Request,
    _token: dict = Depends(validate_token),
):
    settings = request.app.state.settings
    api_version = request.query_params.get(
        "api-version", settings.azure_openai_api_version
    )

    body = await request.body()
    client = _get_azure_client(request)

    azure_response = await client.call_openai(
        deployment_id=deployment_id,
        operation="chat/completions",
        body=body,
        api_version=api_version,
    )

    return Response(
        content=azure_response.content,
        status_code=azure_response.status_code,
        headers={
            "Content-Type": azure_response.headers.get(
                "content-type", "application/json"
            )
        },
    )


@router.post("/deployments/{deployment_id}/embeddings")
async def embeddings(
    deployment_id: str,
    request: Request,
    _token: dict = Depends(validate_token),
):
    settings = request.app.state.settings
    api_version = request.query_params.get(
        "api-version", settings.azure_openai_api_version
    )

    body = await request.body()
    client = _get_azure_client(request)

    azure_response = await client.call_openai(
        deployment_id=deployment_id,
        operation="embeddings",
        body=body,
        api_version=api_version,
    )

    return Response(
        content=azure_response.content,
        status_code=azure_response.status_code,
        headers={
            "Content-Type": azure_response.headers.get(
                "content-type", "application/json"
            )
        },
    )
