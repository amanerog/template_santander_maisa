import logging
from typing import Optional

from fastapi import APIRouter, Depends, Request, Response

from app.middleware.auth import validate_token
from app.services.azure_client import AzureClient

logger = logging.getLogger(__name__)

router = APIRouter(tags=["Azure Speech"])


def _get_azure_client(request: Request) -> AzureClient:
    return AzureClient(
        http_client=request.app.state.http_client,
        settings=request.app.state.settings,
    )


@router.post("/speech/recognition/conversation/cognitiveservices/v1")
async def speech_to_text_realtime(
    request: Request,
    _token: dict = Depends(validate_token),
):
    content_type = request.headers.get("content-type", "audio/wav")
    body = await request.body()

    query_params = {}
    for key in ("language", "format", "profanity", "wordLevelTimestamps"):
        value = request.query_params.get(key)
        if value:
            query_params[key] = value

    client = _get_azure_client(request)

    azure_response = await client.call_speech_realtime(
        body=body,
        content_type=content_type,
        query_params=query_params,
    )

    return Response(
        content=azure_response.content,
        status_code=azure_response.status_code,
        headers={
            "Content-Type": azure_response.headers.get(
                "content-type", "application/json"
            )
        },
    )


@router.post("/speechtotext/v3.1/transcriptions")
async def create_batch_transcription(
    request: Request,
    _token: dict = Depends(validate_token),
):
    body = await request.body()
    client = _get_azure_client(request)

    azure_response = await client.call_speech_batch(
        method="POST",
        path="/speechtotext/v3.1/transcriptions",
        body=body,
    )

    return Response(
        content=azure_response.content,
        status_code=azure_response.status_code,
        headers={
            "Content-Type": azure_response.headers.get(
                "content-type", "application/json"
            )
        },
    )


@router.get("/speechtotext/v3.1/transcriptions/{transcription_id}")
async def get_transcription_status(
    transcription_id: str,
    request: Request,
    _token: dict = Depends(validate_token),
):
    client = _get_azure_client(request)

    azure_response = await client.call_speech_batch(
        method="GET",
        path=f"/speechtotext/v3.1/transcriptions/{transcription_id}",
    )

    return Response(
        content=azure_response.content,
        status_code=azure_response.status_code,
        headers={
            "Content-Type": azure_response.headers.get(
                "content-type", "application/json"
            )
        },
    )


@router.get("/speechtotext/v3.1/transcriptions/{transcription_id}/files")
async def get_transcription_files(
    transcription_id: str,
    request: Request,
    _token: dict = Depends(validate_token),
):
    client = _get_azure_client(request)

    azure_response = await client.call_speech_batch(
        method="GET",
        path=f"/speechtotext/v3.1/transcriptions/{transcription_id}/files",
    )

    return Response(
        content=azure_response.content,
        status_code=azure_response.status_code,
        headers={
            "Content-Type": azure_response.headers.get(
                "content-type", "application/json"
            )
        },
    )


@router.delete("/speechtotext/v3.1/transcriptions/{transcription_id}")
async def delete_transcription(
    transcription_id: str,
    request: Request,
    _token: dict = Depends(validate_token),
):
    client = _get_azure_client(request)

    azure_response = await client.call_speech_batch(
        method="DELETE",
        path=f"/speechtotext/v3.1/transcriptions/{transcription_id}",
    )

    return Response(
        content=azure_response.content,
        status_code=azure_response.status_code,
        headers={
            "Content-Type": azure_response.headers.get(
                "content-type", "application/json"
            )
        },
    )
