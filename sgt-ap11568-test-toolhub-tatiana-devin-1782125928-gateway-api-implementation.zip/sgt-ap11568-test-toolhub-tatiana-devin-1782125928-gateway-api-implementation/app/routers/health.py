from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse

router = APIRouter(tags=["Health"])


@router.get("/health")
async def liveness():
    return JSONResponse(
        status_code=200,
        content={"status": "UP"},
    )


@router.get("/health/ready")
async def readiness(request: Request):
    try:
        settings = request.app.state.settings
        http_client = request.app.state.http_client

        if not settings or not http_client:
            return JSONResponse(
                status_code=503,
                content={"status": "DOWN", "reason": "Dependencies not initialized"},
            )

        return JSONResponse(
            status_code=200,
            content={"status": "UP", "environment": settings.environment},
        )
    except Exception:
        return JSONResponse(
            status_code=503,
            content={"status": "DOWN", "reason": "Configuration not loaded"},
        )
