from pydantic_settings import BaseSettings
from pydantic import Field


class Settings(BaseSettings):
    # Azure OpenAI
    azure_openai_endpoint: str = Field(..., description="Azure OpenAI resource endpoint")
    azure_openai_api_key: str = Field(..., description="Azure OpenAI API key")
    azure_openai_api_version: str = Field(
        default="2024-02-01", description="Azure OpenAI API version"
    )

    # Azure Speech
    azure_speech_endpoint: str = Field(..., description="Azure Speech service endpoint")
    azure_speech_api_key: str = Field(..., description="Azure Speech service key")
    azure_speech_region: str = Field(..., description="Azure Speech region")

    # Langfuse
    langfuse_public_key: str = Field(..., description="Langfuse public key")
    langfuse_secret_key: str = Field(..., description="Langfuse secret key")
    langfuse_host: str = Field(..., description="Langfuse instance URL")

    # Entra ID
    entra_tenant_id: str = Field(..., description="Microsoft Entra ID tenant ID")
    entra_client_id: str = Field(..., description="Expected audience for token validation")

    # Application
    environment: str = Field(default="DEV", description="Current environment (DEV/PRE/PRO)")
    log_level: str = Field(default="INFO", description="Logging level")

    # Timeouts
    openai_timeout_seconds: int = Field(default=60, description="Timeout for OpenAI calls")
    speech_timeout_seconds: int = Field(default=120, description="Timeout for Speech calls")

    # Retry
    max_retry_attempts: int = Field(default=3, description="Maximum retry attempts")
    retry_initial_wait: float = Field(default=1.0, description="Initial retry wait in seconds")
    retry_max_wait: float = Field(default=10.0, description="Maximum retry wait in seconds")

    class Config:
        env_file = ".env"
        case_sensitive = False


def get_settings() -> Settings:
    return Settings()
