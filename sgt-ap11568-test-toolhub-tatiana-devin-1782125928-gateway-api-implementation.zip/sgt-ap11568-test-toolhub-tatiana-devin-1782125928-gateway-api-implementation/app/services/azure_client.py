import logging
from typing import Optional

import httpx
from tenacity import (
    retry,
    retry_if_result,
    stop_after_attempt,
    wait_exponential,
)

logger = logging.getLogger(__name__)


def _should_retry(response: httpx.Response) -> bool:
    return response.status_code in (429, 500, 502, 503, 504)


class AzureClient:
    def __init__(self, http_client: httpx.AsyncClient, settings):
        self._client = http_client
        self._settings = settings

    @retry(
        retry=retry_if_result(_should_retry),
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=1, max=10),
        reraise=True,
    )
    async def call_openai(
        self,
        deployment_id: str,
        operation: str,
        body: bytes,
        api_version: str,
        content_type: str = "application/json",
    ) -> httpx.Response:
        url = (
            f"{self._settings.azure_openai_endpoint}/openai/deployments/"
            f"{deployment_id}/{operation}"
        )
        params = {"api-version": api_version}
        headers = {
            "api-key": self._settings.azure_openai_api_key,
            "Content-Type": content_type,
        }

        response = await self._client.post(
            url,
            content=body,
            params=params,
            headers=headers,
            timeout=float(self._settings.openai_timeout_seconds),
        )

        if _should_retry(response):
            retry_after = response.headers.get("Retry-After")
            if retry_after:
                logger.warning(
                    f"Azure OpenAI returned {response.status_code}, "
                    f"Retry-After: {retry_after}s"
                )
            return response

        return response

    @retry(
        retry=retry_if_result(_should_retry),
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=1, max=10),
        reraise=True,
    )
    async def call_speech_realtime(
        self,
        body: bytes,
        content_type: str,
        query_params: dict,
    ) -> httpx.Response:
        url = (
            f"{self._settings.azure_speech_endpoint}"
            f"/speech/recognition/conversation/cognitiveservices/v1"
        )
        headers = {
            "Ocp-Apim-Subscription-Key": self._settings.azure_speech_api_key,
            "Content-Type": content_type,
        }

        response = await self._client.post(
            url,
            content=body,
            params=query_params,
            headers=headers,
            timeout=float(self._settings.speech_timeout_seconds),
        )

        if _should_retry(response):
            return response

        return response

    @retry(
        retry=retry_if_result(_should_retry),
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=1, max=10),
        reraise=True,
    )
    async def call_speech_batch(
        self,
        method: str,
        path: str,
        body: Optional[bytes] = None,
        content_type: str = "application/json",
    ) -> httpx.Response:
        url = f"{self._settings.azure_speech_endpoint}{path}"
        headers = {
            "Ocp-Apim-Subscription-Key": self._settings.azure_speech_api_key,
            "Content-Type": content_type,
        }

        response = await self._client.request(
            method=method,
            url=url,
            content=body,
            headers=headers,
            timeout=float(self._settings.speech_timeout_seconds),
        )

        if _should_retry(response):
            return response

        return response
