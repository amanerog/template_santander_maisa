import logging
from contextlib import asynccontextmanager

import httpx
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import get_settings
from app.middleware.audit import AuditMiddleware
from app.middleware.logging_middleware import RequestLoggingMiddleware
from app.routers import health, openai, speech
from app.utils.logging_config import setup_logging


@asynccontextmanager
async def lifespan(application: FastAPI):
    settings = get_settings()
    setup_logging(settings.log_level)

    application.state.settings = settings
    application.state.http_client = httpx.AsyncClient(
        timeout=httpx.Timeout(
            connect=10.0,
            read=float(settings.openai_timeout_seconds),
            write=30.0,
            pool=10.0,
        ),
        limits=httpx.Limits(max_connections=100, max_keepalive_connections=20),
    )

    logger = logging.getLogger(__name__)
    logger.info(
        "Gateway API started",
        extra={"environment": settings.environment},
    )

    yield

    await application.state.http_client.aclose()
    logger.info("Gateway API shutdown")


app = FastAPI(
    title="Gateway API - Azure Cognitive Services Proxy",
    description="Intermediary between third-party developments and Azure Cognitive Services",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.add_middleware(AuditMiddleware)
app.add_middleware(RequestLoggingMiddleware)

app.include_router(health.router)
app.include_router(openai.router)
app.include_router(speech.router)
