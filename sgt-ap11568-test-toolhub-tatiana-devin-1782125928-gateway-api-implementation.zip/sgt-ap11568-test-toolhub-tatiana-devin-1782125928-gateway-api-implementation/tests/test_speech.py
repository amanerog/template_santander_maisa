import json

import httpx
import pytest
import respx


@pytest.mark.asyncio
@respx.mock
async def test_speech_to_text_realtime_success(client, auth_headers):
    transcription_response = {
        "RecognitionStatus": "Success",
        "DisplayText": "Hello world.",
        "Offset": 0,
        "Duration": 50000000,
    }

    respx.post(
        "https://test-speech.cognitiveservices.azure.com"
        "/speech/recognition/conversation/cognitiveservices/v1"
    ).mock(return_value=httpx.Response(200, json=transcription_response))

    response = await client.post(
        "/speech/recognition/conversation/cognitiveservices/v1?language=en-US&format=simple",
        headers={**auth_headers, "content-type": "audio/wav"},
        content=b"fake-audio-data",
    )

    assert response.status_code == 200
    data = response.json()
    assert data["RecognitionStatus"] == "Success"
    assert data["DisplayText"] == "Hello world."


@pytest.mark.asyncio
@respx.mock
async def test_speech_to_text_realtime_forwards_query_params(client, auth_headers):
    respx.post(
        "https://test-speech.cognitiveservices.azure.com"
        "/speech/recognition/conversation/cognitiveservices/v1"
    ).mock(return_value=httpx.Response(200, json={"RecognitionStatus": "Success"}))

    response = await client.post(
        "/speech/recognition/conversation/cognitiveservices/v1"
        "?language=es-ES&format=detailed&profanity=masked",
        headers={**auth_headers, "content-type": "audio/ogg"},
        content=b"fake-audio-data",
    )

    assert response.status_code == 200
    call = respx.calls[0]
    assert "language=es-ES" in str(call.request.url)
    assert "format=detailed" in str(call.request.url)
    assert "profanity=masked" in str(call.request.url)


@pytest.mark.asyncio
@respx.mock
async def test_speech_to_text_azure_error(client, auth_headers):
    respx.post(
        "https://test-speech.cognitiveservices.azure.com"
        "/speech/recognition/conversation/cognitiveservices/v1"
    ).mock(return_value=httpx.Response(400, json={"error": "Invalid audio format"}))

    response = await client.post(
        "/speech/recognition/conversation/cognitiveservices/v1?language=en-US",
        headers={**auth_headers, "content-type": "audio/wav"},
        content=b"bad-audio",
    )

    assert response.status_code == 400


@pytest.mark.asyncio
@respx.mock
async def test_batch_transcription_create(client, auth_headers):
    batch_response = {
        "self": "https://test-speech.cognitiveservices.azure.com/speechtotext/v3.1/transcriptions/123",
        "status": "NotStarted",
    }

    respx.post(
        "https://test-speech.cognitiveservices.azure.com/speechtotext/v3.1/transcriptions"
    ).mock(return_value=httpx.Response(201, json=batch_response))

    response = await client.post(
        "/speechtotext/v3.1/transcriptions",
        headers=auth_headers,
        json={
            "contentUrls": ["https://storage.blob.core.windows.net/audio/test.wav"],
            "locale": "en-US",
            "displayName": "Test transcription",
        },
    )

    assert response.status_code == 201
    data = response.json()
    assert data["status"] == "NotStarted"


@pytest.mark.asyncio
@respx.mock
async def test_batch_transcription_get_status(client, auth_headers):
    status_response = {
        "self": "https://test-speech.cognitiveservices.azure.com/speechtotext/v3.1/transcriptions/123",
        "status": "Succeeded",
    }

    respx.get(
        "https://test-speech.cognitiveservices.azure.com/speechtotext/v3.1/transcriptions/123"
    ).mock(return_value=httpx.Response(200, json=status_response))

    response = await client.get(
        "/speechtotext/v3.1/transcriptions/123",
        headers=auth_headers,
    )

    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "Succeeded"


@pytest.mark.asyncio
@respx.mock
async def test_batch_transcription_get_files(client, auth_headers):
    files_response = {
        "values": [
            {"name": "result.json", "kind": "Transcription"}
        ]
    }

    respx.get(
        "https://test-speech.cognitiveservices.azure.com/speechtotext/v3.1/transcriptions/123/files"
    ).mock(return_value=httpx.Response(200, json=files_response))

    response = await client.get(
        "/speechtotext/v3.1/transcriptions/123/files",
        headers=auth_headers,
    )

    assert response.status_code == 200
    data = response.json()
    assert len(data["values"]) == 1


@pytest.mark.asyncio
@respx.mock
async def test_batch_transcription_delete(client, auth_headers):
    respx.delete(
        "https://test-speech.cognitiveservices.azure.com/speechtotext/v3.1/transcriptions/123"
    ).mock(return_value=httpx.Response(204))

    response = await client.delete(
        "/speechtotext/v3.1/transcriptions/123",
        headers=auth_headers,
    )

    assert response.status_code == 204


@pytest.mark.asyncio
@respx.mock
async def test_speech_requires_auth(client):
    response = await client.post(
        "/speech/recognition/conversation/cognitiveservices/v1",
        content=b"audio",
    )
    assert response.status_code == 401
