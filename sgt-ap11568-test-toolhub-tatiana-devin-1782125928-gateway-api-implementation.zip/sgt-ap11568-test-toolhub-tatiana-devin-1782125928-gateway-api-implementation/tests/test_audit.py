import json

import httpx
import pytest
import respx
from unittest.mock import MagicMock, patch


@pytest.mark.asyncio
@respx.mock
async def test_audit_trace_created_on_openai_call(client, auth_headers, mock_langfuse):
    respx.post(
        "https://test-openai.openai.azure.com/openai/deployments/gpt-4/chat/completions"
    ).mock(
        return_value=httpx.Response(
            200,
            json={
                "choices": [{"message": {"content": "Hi"}}],
                "usage": {"prompt_tokens": 5, "completion_tokens": 2, "total_tokens": 7},
            },
        )
    )

    response = await client.post(
        "/openai/deployments/gpt-4/chat/completions?api-version=2024-02-01",
        headers=auth_headers,
        json={"messages": [{"role": "user", "content": "Hello"}]},
    )

    assert response.status_code == 200
    mock_langfuse.trace.assert_called_once()
    trace_kwargs = mock_langfuse.trace.call_args[1]
    assert trace_kwargs["name"] == "chat_completions"
    assert trace_kwargs["user_id"] == "test-consumer-app-id"
    assert trace_kwargs["metadata"]["environment"] == "DEV"
    assert trace_kwargs["metadata"]["deployment_id"] == "gpt-4"
    assert trace_kwargs["metadata"]["http_status_code"] == 200


@pytest.mark.asyncio
@respx.mock
async def test_audit_trace_captures_error(client, auth_headers, mock_langfuse):
    respx.post(
        "https://test-openai.openai.azure.com/openai/deployments/gpt-4/chat/completions"
    ).mock(
        return_value=httpx.Response(
            400,
            json={"error": {"message": "Invalid request", "code": "BadRequest"}},
        )
    )

    response = await client.post(
        "/openai/deployments/gpt-4/chat/completions?api-version=2024-02-01",
        headers=auth_headers,
        json={"messages": []},
    )

    assert response.status_code == 400
    mock_langfuse.trace.assert_called_once()
    trace_kwargs = mock_langfuse.trace.call_args[1]
    assert trace_kwargs["metadata"]["http_status_code"] == 400


@pytest.mark.asyncio
@respx.mock
async def test_audit_generation_includes_token_usage(client, auth_headers, mock_langfuse):
    respx.post(
        "https://test-openai.openai.azure.com/openai/deployments/gpt-4/chat/completions"
    ).mock(
        return_value=httpx.Response(
            200,
            json={
                "choices": [{"message": {"content": "Hi"}}],
                "usage": {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15},
            },
        )
    )

    response = await client.post(
        "/openai/deployments/gpt-4/chat/completions?api-version=2024-02-01",
        headers=auth_headers,
        json={"messages": [{"role": "user", "content": "Hello"}]},
    )

    assert response.status_code == 200
    trace_mock = mock_langfuse.trace.return_value
    trace_mock.generation.assert_called_once()
    gen_kwargs = trace_mock.generation.call_args[1]
    assert gen_kwargs["usage"]["prompt_tokens"] == 10
    assert gen_kwargs["usage"]["completion_tokens"] == 5
    assert gen_kwargs["usage"]["total_tokens"] == 15
    assert gen_kwargs["model"] == "gpt-4"


@pytest.mark.asyncio
@respx.mock
async def test_audit_does_not_block_on_langfuse_failure(client, auth_headers):
    """If Langfuse fails, the request should still succeed."""
    respx.post(
        "https://test-openai.openai.azure.com/openai/deployments/gpt-4/chat/completions"
    ).mock(
        return_value=httpx.Response(200, json={"choices": []})
    )

    with patch("app.middleware.audit._get_langfuse_client") as mock_client:
        mock_client.side_effect = Exception("Langfuse connection error")
        response = await client.post(
            "/openai/deployments/gpt-4/chat/completions?api-version=2024-02-01",
            headers=auth_headers,
            json={"messages": [{"role": "user", "content": "Hello"}]},
        )

    assert response.status_code == 200


@pytest.mark.asyncio
async def test_audit_skips_health_endpoints(client, mock_langfuse):
    response = await client.get("/health")
    assert response.status_code == 200
    mock_langfuse.trace.assert_not_called()
