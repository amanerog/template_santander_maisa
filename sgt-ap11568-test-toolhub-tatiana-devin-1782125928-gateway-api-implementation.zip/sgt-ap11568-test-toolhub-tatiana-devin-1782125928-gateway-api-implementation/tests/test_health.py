import pytest


@pytest.mark.asyncio
async def test_liveness_returns_200(client):
    response = await client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "UP"


@pytest.mark.asyncio
async def test_readiness_returns_200(client):
    response = await client.get("/health/ready")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "UP"
    assert data["environment"] == "DEV"


@pytest.mark.asyncio
async def test_health_no_auth_required(client):
    """Health endpoints should not require authentication."""
    response = await client.get("/health")
    assert response.status_code == 200

    response = await client.get("/health/ready")
    assert response.status_code == 200
