import json

import httpx
import pytest
import respx


@pytest.mark.asyncio
@respx.mock
async def test_chat_completions_success(client, auth_headers):
    azure_response = {
        "id": "chatcmpl-123",
        "object": "chat.completion",
        "choices": [
            {
                "index": 0,
                "message": {"role": "assistant", "content": "Hello!"},
                "finish_reason": "stop",
            }
        ],
        "usage": {
            "prompt_tokens": 10,
            "completion_tokens": 5,
            "total_tokens": 15,
        },
    }

    respx.post(
        "https://test-openai.openai.azure.com/openai/deployments/gpt-4/chat/completions"
    ).mock(return_value=httpx.Response(200, json=azure_response))

    response = await client.post(
        "/openai/deployments/gpt-4/chat/completions?api-version=2024-02-01",
        headers=auth_headers,
        json={"messages": [{"role": "user", "content": "Hello"}]},
    )

    assert response.status_code == 200
    data = response.json()
    assert data["choices"][0]["message"]["content"] == "Hello!"
    assert data["usage"]["total_tokens"] == 15


@pytest.mark.asyncio
@respx.mock
async def test_chat_completions_azure_error_propagation(client, auth_headers):
    error_response = {
        "error": {
            "message": "The model deployment was not found.",
            "type": "invalid_request_error",
            "code": "DeploymentNotFound",
        }
    }

    respx.post(
        "https://test-openai.openai.azure.com/openai/deployments/nonexistent/chat/completions"
    ).mock(return_value=httpx.Response(404, json=error_response))

    response = await client.post(
        "/openai/deployments/nonexistent/chat/completions?api-version=2024-02-01",
        headers=auth_headers,
        json={"messages": [{"role": "user", "content": "Hello"}]},
    )

    assert response.status_code == 404
    data = response.json()
    assert data["error"]["code"] == "DeploymentNotFound"


@pytest.mark.asyncio
@respx.mock
async def test_chat_completions_forwards_api_version(client, auth_headers):
    respx.post(
        "https://test-openai.openai.azure.com/openai/deployments/gpt-4/chat/completions"
    ).mock(return_value=httpx.Response(200, json={"choices": []}))

    response = await client.post(
        "/openai/deployments/gpt-4/chat/completions?api-version=2024-06-01",
        headers=auth_headers,
        json={"messages": [{"role": "user", "content": "Hello"}]},
    )

    assert response.status_code == 200
    call = respx.calls[0]
    assert "api-version=2024-06-01" in str(call.request.url)


@pytest.mark.asyncio
@respx.mock
async def test_embeddings_success(client, auth_headers):
    azure_response = {
        "object": "list",
        "data": [
            {"object": "embedding", "index": 0, "embedding": [0.1, 0.2, 0.3]}
        ],
        "model": "text-embedding-ada-002",
        "usage": {"prompt_tokens": 5, "total_tokens": 5},
    }

    respx.post(
        "https://test-openai.openai.azure.com/openai/deployments/text-embedding-ada-002/embeddings"
    ).mock(return_value=httpx.Response(200, json=azure_response))

    response = await client.post(
        "/openai/deployments/text-embedding-ada-002/embeddings?api-version=2024-02-01",
        headers=auth_headers,
        json={"input": "Hello world"},
    )

    assert response.status_code == 200
    data = response.json()
    assert data["data"][0]["embedding"] == [0.1, 0.2, 0.3]
    assert data["usage"]["total_tokens"] == 5


@pytest.mark.asyncio
@respx.mock
async def test_embeddings_azure_error(client, auth_headers):
    respx.post(
        "https://test-openai.openai.azure.com/openai/deployments/bad-model/embeddings"
    ).mock(return_value=httpx.Response(400, json={"error": {"message": "Bad request"}}))

    response = await client.post(
        "/openai/deployments/bad-model/embeddings?api-version=2024-02-01",
        headers=auth_headers,
        json={"input": ""},
    )

    assert response.status_code == 400


@pytest.mark.asyncio
@respx.mock
async def test_chat_completions_requires_auth(client):
    response = await client.post(
        "/openai/deployments/gpt-4/chat/completions",
        json={"messages": [{"role": "user", "content": "Hello"}]},
    )
    assert response.status_code == 401
