import os
import time

import pytest
import httpx
from unittest.mock import AsyncMock, MagicMock, patch
import jwt
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.backends import default_backend

# Set required env vars before importing app
os.environ.update({
    "AZURE_OPENAI_ENDPOINT": "https://test-openai.openai.azure.com",
    "AZURE_OPENAI_API_KEY": "test-openai-key",
    "AZURE_OPENAI_API_VERSION": "2024-02-01",
    "AZURE_SPEECH_ENDPOINT": "https://test-speech.cognitiveservices.azure.com",
    "AZURE_SPEECH_API_KEY": "test-speech-key",
    "AZURE_SPEECH_REGION": "westeurope",
    "LANGFUSE_PUBLIC_KEY": "pk-test",
    "LANGFUSE_SECRET_KEY": "sk-test",
    "LANGFUSE_HOST": "https://langfuse.test.com",
    "ENTRA_TENANT_ID": "test-tenant-id",
    "ENTRA_CLIENT_ID": "test-client-id",
    "ENVIRONMENT": "DEV",
})


from app.main import app
from app.config import get_settings


# RSA key pair for test JWT signing
_private_key = rsa.generate_private_key(
    public_exponent=65537,
    key_size=2048,
    backend=default_backend(),
)
_public_key = _private_key.public_key()

# Get public key numbers for JWKS
_pub_numbers = _public_key.public_numbers()


def _int_to_base64url(n: int) -> str:
    import base64
    byte_length = (n.bit_length() + 7) // 8
    n_bytes = n.to_bytes(byte_length, byteorder="big")
    return base64.urlsafe_b64encode(n_bytes).rstrip(b"=").decode()


TEST_KID = "test-kid-123"
TEST_JWKS = {
    "keys": [
        {
            "kty": "RSA",
            "kid": TEST_KID,
            "use": "sig",
            "n": _int_to_base64url(_pub_numbers.n),
            "e": _int_to_base64url(_pub_numbers.e),
        }
    ]
}


def create_test_token(
    expired: bool = False,
    wrong_audience: bool = False,
    wrong_issuer: bool = False,
    kid: str = TEST_KID,
    azp: str = "test-consumer-app-id",
) -> str:
    now = int(time.time())
    payload = {
        "iss": (
            "https://login.microsoftonline.com/wrong-tenant/v2.0"
            if wrong_issuer
            else "https://login.microsoftonline.com/test-tenant-id/v2.0"
        ),
        "aud": "wrong-audience" if wrong_audience else "test-client-id",
        "sub": "user-123",
        "azp": azp,
        "exp": now - 3600 if expired else now + 3600,
        "nbf": now - 60,
        "iat": now,
    }

    private_pem = _private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )

    return jwt.encode(
        payload,
        private_pem,
        algorithm="RS256",
        headers={"kid": kid},
    )


@pytest.fixture
def valid_token():
    return create_test_token()


@pytest.fixture
def expired_token():
    return create_test_token(expired=True)


@pytest.fixture
def wrong_audience_token():
    return create_test_token(wrong_audience=True)


@pytest.fixture
def wrong_issuer_token():
    return create_test_token(wrong_issuer=True)


@pytest.fixture
def auth_headers(valid_token):
    return {"Authorization": f"Bearer {valid_token}"}


@pytest.fixture
def mock_jwks():
    """Mock the JWKS fetch to return test keys."""
    with patch("app.middleware.auth._fetch_jwks", new_callable=AsyncMock) as mock:
        mock.return_value = TEST_JWKS
        yield mock


@pytest.fixture
def mock_langfuse():
    """Mock Langfuse client."""
    with patch("app.middleware.audit._get_langfuse_client") as mock:
        langfuse_mock = MagicMock()
        trace_mock = MagicMock()
        langfuse_mock.trace.return_value = trace_mock
        trace_mock.generation.return_value = MagicMock()
        trace_mock.span.return_value = MagicMock()
        mock.return_value = langfuse_mock
        yield langfuse_mock


@pytest.fixture
async def client(mock_jwks, mock_langfuse):
    """Create test client with mocked dependencies and proper app state."""
    from httpx import ASGITransport, AsyncClient

    settings = get_settings()
    app.state.settings = settings
    app.state.http_client = httpx.AsyncClient(
        timeout=httpx.Timeout(connect=10.0, read=60.0, write=30.0, pool=10.0),
    )

    async with AsyncClient(
        transport=ASGITransport(app=app),
        base_url="http://test",
    ) as ac:
        yield ac

    await app.state.http_client.aclose()
