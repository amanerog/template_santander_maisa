import pytest
from tests.conftest import create_test_token


@pytest.mark.asyncio
async def test_missing_auth_header(client):
    response = await client.post(
        "/openai/deployments/gpt-4/chat/completions",
        json={"messages": [{"role": "user", "content": "hello"}]},
    )
    assert response.status_code == 401
    data = response.json()
    assert data["detail"]["title"] == "Unauthorized"
    assert "Missing or invalid Authorization" in data["detail"]["detail"]


@pytest.mark.asyncio
async def test_invalid_token_format(client):
    response = await client.post(
        "/openai/deployments/gpt-4/chat/completions",
        headers={"Authorization": "Bearer not-a-valid-jwt"},
        json={"messages": [{"role": "user", "content": "hello"}]},
    )
    assert response.status_code == 401


@pytest.mark.asyncio
async def test_expired_token(client, expired_token):
    response = await client.post(
        "/openai/deployments/gpt-4/chat/completions",
        headers={"Authorization": f"Bearer {expired_token}"},
        json={"messages": [{"role": "user", "content": "hello"}]},
    )
    assert response.status_code == 401
    data = response.json()
    assert "expired" in data["detail"]["detail"].lower()


@pytest.mark.asyncio
async def test_wrong_audience_token(client, wrong_audience_token):
    response = await client.post(
        "/openai/deployments/gpt-4/chat/completions",
        headers={"Authorization": f"Bearer {wrong_audience_token}"},
        json={"messages": [{"role": "user", "content": "hello"}]},
    )
    assert response.status_code == 401


@pytest.mark.asyncio
async def test_wrong_issuer_token(client, wrong_issuer_token):
    response = await client.post(
        "/openai/deployments/gpt-4/chat/completions",
        headers={"Authorization": f"Bearer {wrong_issuer_token}"},
        json={"messages": [{"role": "user", "content": "hello"}]},
    )
    assert response.status_code == 401


@pytest.mark.asyncio
async def test_missing_bearer_prefix(client, valid_token):
    response = await client.post(
        "/openai/deployments/gpt-4/chat/completions",
        headers={"Authorization": valid_token},
        json={"messages": [{"role": "user", "content": "hello"}]},
    )
    assert response.status_code == 401


@pytest.mark.asyncio
async def test_unknown_kid(client):
    token = create_test_token(kid="unknown-kid")
    response = await client.post(
        "/openai/deployments/gpt-4/chat/completions",
        headers={"Authorization": f"Bearer {token}"},
        json={"messages": [{"role": "user", "content": "hello"}]},
    )
    assert response.status_code == 401
