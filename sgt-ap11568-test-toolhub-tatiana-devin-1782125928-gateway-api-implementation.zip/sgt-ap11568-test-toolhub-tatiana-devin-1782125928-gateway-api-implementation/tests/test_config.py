import os

import pytest
from pydantic import ValidationError


def test_config_loads_from_environment():
    from app.config import Settings

    settings = Settings()
    assert settings.azure_openai_endpoint == "https://test-openai.openai.azure.com"
    assert settings.azure_openai_api_key == "test-openai-key"
    assert settings.azure_speech_endpoint == "https://test-speech.cognitiveservices.azure.com"
    assert settings.azure_speech_region == "westeurope"
    assert settings.langfuse_host == "https://langfuse.test.com"
    assert settings.entra_tenant_id == "test-tenant-id"
    assert settings.entra_client_id == "test-client-id"
    assert settings.environment == "DEV"


def test_config_defaults():
    from app.config import Settings

    settings = Settings()
    assert settings.azure_openai_api_version == "2024-02-01"
    assert settings.log_level == "INFO"
    assert settings.openai_timeout_seconds == 60
    assert settings.speech_timeout_seconds == 120
    assert settings.max_retry_attempts == 3


def test_config_fails_on_missing_required():
    """Config should fail if required vars are missing."""
    env_backup = {}
    required_vars = [
        "AZURE_OPENAI_ENDPOINT",
        "AZURE_OPENAI_API_KEY",
        "AZURE_SPEECH_ENDPOINT",
        "AZURE_SPEECH_API_KEY",
        "AZURE_SPEECH_REGION",
        "LANGFUSE_PUBLIC_KEY",
        "LANGFUSE_SECRET_KEY",
        "LANGFUSE_HOST",
        "ENTRA_TENANT_ID",
        "ENTRA_CLIENT_ID",
    ]

    for var in required_vars:
        env_backup[var] = os.environ.get(var)

    # Remove one required var to trigger validation error
    os.environ.pop("AZURE_OPENAI_ENDPOINT", None)

    try:
        from app.config import Settings

        with pytest.raises(ValidationError):
            Settings(_env_file=None)
    finally:
        for var, value in env_backup.items():
            if value is not None:
                os.environ[var] = value
