from setuptools import setup, find_packages

setup(
    name="gateway-api",
    version="1.0.0",
    description="Gateway API - Azure Cognitive Services Proxy",
    packages=find_packages(),
    python_requires=">=3.12",
)
