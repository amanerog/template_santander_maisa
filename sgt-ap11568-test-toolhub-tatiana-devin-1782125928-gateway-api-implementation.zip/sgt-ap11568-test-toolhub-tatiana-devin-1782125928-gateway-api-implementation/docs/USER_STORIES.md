# User Stories — Gateway API (Azure Cognitive Services Proxy)

## US-01: Project Scaffolding & FastAPI Application Setup

### Functional Description
As a developer, I need a well-structured Python project with FastAPI as the web framework, so that the gateway API has a solid foundation with proper packaging, dependency management, and entrypoint configuration ready for containerized deployment on AKS.

### Technical Description
- Application module structure: `app/` with `main.py`, `config.py`, `routers/`, `services/`, `middleware/`, `models/`, `utils/`
- FastAPI application with CORS, exception handlers, and OpenAPI docs
- `Pipfile` with dependencies: `fastapi`, `uvicorn`, `httpx`, `pydantic`, `pydantic-settings`, `python-jose[cryptography]`, `langfuse`, `tenacity`, `python-multipart`
- `entrypoint.sh` to launch uvicorn on port 8080
- `Dockerfile` for containerized deployment
- `setup.py` with package metadata

### Acceptance Criteria
- Application starts successfully with `uvicorn` on port 8080
- OpenAPI docs accessible at `/docs`
- Health check endpoint responds at `/health` with 200 OK
- Docker image builds without errors
- All dependencies resolve from the configured Nexus PyPI proxy
- Project follows the existing Gluon CI/CD pipeline structure

---

## US-02: Environment Configuration Management

### Functional Description
As a platform operator, I need all environment-specific configuration (Azure endpoints, API keys, Langfuse URLs) to be externalized via Kubernetes ConfigMaps and Secrets, so that the same container image can be deployed across DEV, PRE, and PRO without code changes.

### Technical Description
- `app/config.py` using `pydantic-settings.BaseSettings` to load configuration from environment variables
- Configuration parameters:
  - `AZURE_OPENAI_ENDPOINT` — Azure OpenAI resource endpoint
  - `AZURE_OPENAI_API_KEY` — Azure OpenAI API key
  - `AZURE_OPENAI_API_VERSION` — API version (default: `2024-02-01`)
  - `AZURE_SPEECH_ENDPOINT` — Azure Speech service endpoint
  - `AZURE_SPEECH_API_KEY` — Azure Speech service key
  - `AZURE_SPEECH_REGION` — Azure Speech region
  - `LANGFUSE_PUBLIC_KEY` — Langfuse public key
  - `LANGFUSE_SECRET_KEY` — Langfuse secret key
  - `LANGFUSE_HOST` — Langfuse instance URL
  - `ENTRA_TENANT_ID` — Microsoft Entra ID tenant ID
  - `ENTRA_CLIENT_ID` — Expected audience for token validation
  - `ENVIRONMENT` — Current environment (DEV/PRE/PRO)
- Helm `values-{env}.yaml` per environment with `extraEnvVars` and `extraEnvVarsSecret` references
- Sensitive values from Kubernetes Secrets; non-sensitive from ConfigMaps

### Acceptance Criteria
- Application fails fast on startup if required configuration is missing
- All secrets injected via K8s Secrets, never hardcoded
- Each environment has its own `values-{env}.yaml` with environment-specific overrides
- Configuration is immutable at runtime
- No secret values appear in logs or error messages

---

## US-03: Entra ID Authentication — Token Validation Middleware

### Functional Description
As a security architect, I need all incoming API requests to be authenticated via Microsoft Entra ID bearer tokens, so that only authorized third-party consumers with valid tokens can access the gateway.

### Technical Description
- `app/middleware/auth.py` as a FastAPI dependency
- Fetch Entra ID JWKS from `https://login.microsoftonline.com/{tenant_id}/discovery/v2.0/keys` with caching (TTL ~24h, refresh on key miss)
- Validate JWT bearer token:
  - Verify signature against JWKS
  - Validate `iss`, `aud`, `exp`, `nbf`
- Extract consumer identity from `azp` claim (authorized party / client_id)
- Return 401 with RFC 7807 problem detail on invalid/missing token
- Exempt `/health` and `/docs` endpoints from authentication

### Acceptance Criteria
- Requests without `Authorization` header receive 401
- Requests with expired tokens receive 401
- Requests with tokens from wrong tenant/audience receive 401
- Requests with valid tokens pass through with consumer identity extracted
- JWKS keys are cached and refreshed transparently
- `/health` endpoint is accessible without authentication

---

## US-04: Azure OpenAI — Chat Completions Proxy

### Functional Description
As a third-party developer, I need to call the chat completions endpoint through the gateway using the same contract as Azure OpenAI's API, so that I can integrate AI capabilities without direct access to the Azure resource.

### Technical Description
- Endpoint: `POST /openai/deployments/{deployment_id}/chat/completions`
- Mirror Azure OpenAI's request/response contract (pass-through proxy)
- Forward `api-version` query parameter and full request body
- Use `httpx.AsyncClient` with `api-key` header
- Propagate Azure's HTTP status codes and error responses transparently

### Acceptance Criteria
- Request body forwarded without modification
- Response returned without modification
- Azure error responses (400, 404, 429, 500) propagated as-is
- `deployment_id` allows targeting any deployed model
- `api-version` query parameter forwarded correctly
- Authentication required

---

## US-05: Azure OpenAI — Embeddings Proxy

### Functional Description
As a third-party developer, I need to call the embeddings endpoint through the gateway using the same contract as Azure OpenAI's API, so that I can generate text embeddings without direct access to the Azure resource.

### Technical Description
- Endpoint: `POST /openai/deployments/{deployment_id}/embeddings`
- Mirror Azure OpenAI's embeddings request/response contract
- Forward `api-version` query parameter and request body
- Use `httpx.AsyncClient` with `api-key` header
- Propagate Azure's HTTP status codes transparently

### Acceptance Criteria
- Embeddings request body forwarded without modification
- Embeddings response returned without modification
- Azure error responses propagated as-is
- `deployment_id` allows targeting any embedding model deployment
- Authentication required

---

## US-06: Azure Speech — Speech-to-Text (Real-Time) Proxy

### Functional Description
As a third-party developer, I need to send audio data to the gateway and receive transcription results using Azure Speech-to-Text, so that I can transcribe speech without direct access to the Azure Speech resource.

### Technical Description
- Endpoint: `POST /speech/recognition/conversation/cognitiveservices/v1`
- Accept audio in request body (binary content)
- Forward query parameters: `language`, `format`, `profanity`, `wordLevelTimestamps`
- Use `Ocp-Apim-Subscription-Key` header
- Return Azure's response as-is

### Acceptance Criteria
- Audio binary data forwarded without modification
- Transcription response returned without modification
- Supports `audio/wav` and `audio/ogg` content types
- Azure error responses propagated as-is
- Authentication required

---

## US-07: Azure Speech — Speech-to-Text (Batch Transcription) Proxy

### Functional Description
As a third-party developer, I need to submit batch transcription jobs and check their status through the gateway, so that I can process large volumes of audio without direct access to the Azure Speech resource.

### Technical Description
- Endpoints:
  - `POST /speechtotext/v3.1/transcriptions` — Create batch transcription
  - `GET /speechtotext/v3.1/transcriptions/{transcription_id}` — Get status
  - `GET /speechtotext/v3.1/transcriptions/{transcription_id}/files` — Get result files
  - `DELETE /speechtotext/v3.1/transcriptions/{transcription_id}` — Delete transcription
- Mirror Azure Speech batch transcription REST API contract
- Use `Ocp-Apim-Subscription-Key` header

### Acceptance Criteria
- Batch transcription CRUD operations forwarded correctly
- Status polling returns Azure's response without modification
- All batch endpoints require authentication
- Azure error responses propagated as-is

---

## US-08: Langfuse Auditing — Full Trace Integration

### Functional Description
As an operations engineer, I need every API call through the gateway to be fully traced in Langfuse with consumer identity, request/response payloads, latency, token usage, and error information, so that all interactions are auditable and observable.

### Technical Description
- `app/middleware/audit.py` as FastAPI middleware
- For each request, create a Langfuse trace with:
  - `trace_id`, `name` (endpoint type), `user_id` (consumer from Entra ID)
  - `metadata`: environment, deployment_id, api_version, http_method, status_code, duration_ms
  - `input`/`output`: full request/response payloads
  - `tags`: [environment, consumer_id, service_type]
- Create generation spans for OpenAI calls with token usage
- Non-blocking: Langfuse failures do not fail requests

### Acceptance Criteria
- Every request generates a trace with full input/output
- Token usage captured for OpenAI calls
- Latency recorded for every call
- Consumer identity attached to every trace
- Environment tag present on all traces
- Langfuse failures do not cause request failures

---

## US-09: Error Handling & Resilience

### Functional Description
As a third-party developer, I need the gateway to handle transient failures from Azure services gracefully with retry logic and clear error responses.

### Technical Description
- Retry on HTTP 429, 500, 502, 503, 504 from Azure
- Exponential backoff (initial=1s, max=10s, max_attempts=3)
- Respect `Retry-After` header from Azure
- Timeout: 60s for OpenAI, 120s for Speech
- RFC 7807 problem details for error responses

### Acceptance Criteria
- Transient Azure errors trigger automatic retry with backoff
- Maximum 3 retry attempts before returning error
- Timeout errors return 504
- All error responses follow RFC 7807 format

---

## US-10: Health Checks & Kubernetes Probes

### Functional Description
As a platform operator, I need the gateway to expose health check endpoints compatible with Kubernetes liveness and readiness probes.

### Technical Description
- `GET /health` — Liveness (lightweight, no external calls)
- `GET /health/ready` — Readiness (verifies config loaded, HTTP client initialized)
- Response format: `{"status": "UP", "environment": "{ENV}"}`
- Both exempt from authentication
- Helm values configured to point probes to these endpoints

### Acceptance Criteria
- `/health` returns 200 when app is running
- `/health/ready` returns 200 when app is ready, 503 otherwise
- Neither endpoint requires authentication
- Probes respond within 1 second

---

## US-11: Structured Logging

### Functional Description
As an operations engineer, I need the gateway to produce structured JSON logs with correlation IDs for tracing requests in a centralized logging platform.

### Technical Description
- JSON formatter with fields: timestamp, level, correlation_id, consumer_id, service, endpoint, duration_ms, status_code, environment
- Log levels: INFO (request start/completion), WARNING (retries), ERROR (exceptions)
- No secrets/keys in logs
- Logs written to stdout for K8s collection

### Acceptance Criteria
- All logs are structured JSON
- Every request has a unique correlation ID
- No credentials in logs
- Log level configurable via environment variable

---

## US-12: Unit & Integration Test Suite

### Functional Description
As a developer, I need a comprehensive test suite covering authentication, proxying, auditing, and error handling for CI pipeline validation.

### Technical Description
- `pytest` + `pytest-asyncio` + `respx` for mocking
- Test coverage: auth, openai proxy, speech proxy, audit, config, health
- Minimum 80% code coverage
- Coverage report in `coverage.xml` for SonarQube

### Acceptance Criteria
- All tests pass with `pytest -v`
- Coverage ≥ 80%
- Tests run without external service dependencies
- CI pipeline executes tests successfully
