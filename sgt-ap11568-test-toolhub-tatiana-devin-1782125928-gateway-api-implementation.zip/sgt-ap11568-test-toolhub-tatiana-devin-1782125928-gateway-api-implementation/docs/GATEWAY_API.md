# Gateway API — Azure Cognitive Services Proxy

## Tool Name
**Gateway API** (Azure Cognitive Services Proxy)

## Scope Description
A Python-based REST API gateway deployed on AKS that acts as an intermediary between third-party developments and Azure Cognitive Services (Azure OpenAI and Azure Speech). It provides transparent proxying with authentication, full auditing, and resilience.

## Boundaries Description
- **In scope**: Azure OpenAI Chat Completions, Azure OpenAI Embeddings, Azure Speech-to-Text (real-time and batch)
- **Out of scope**: Azure DALL-E, Text-to-Speech (TTS), SSE streaming, rate limiting, multi-region failover, direct model management

## Architecture Overview

```
┌──────────────────┐         ┌─────────────────────┐         ┌──────────────────────┐
│  Third-Party     │  REST   │   Gateway API       │  REST   │  Azure Cognitive     │
│  Applications    │────────>│   (FastAPI/AKS)     │────────>│  Services            │
│                  │<────────│                     │<────────│  (OpenAI + Speech)   │
└──────────────────┘         └─────────────────────┘         └──────────────────────┘
                                      │
                                      │ Traces
                                      ▼
                              ┌─────────────────┐
                              │    Langfuse      │
                              │   (Auditing)     │
                              └─────────────────┘
```

## Technology Stack

| Component | Technology |
|-----------|-----------|
| Language | Python 3.14 |
| Framework | FastAPI + Uvicorn |
| HTTP Client | httpx (async) |
| Authentication | Microsoft Entra ID (JWT/JWKS) |
| Auditing | Langfuse SDK |
| Retry/Resilience | Tenacity |
| Configuration | Pydantic Settings |
| Container | UBI 9 |
| Orchestration | AKS (Kubernetes) |
| CI/CD | Gluon |

## API Endpoints

### Azure OpenAI
| Method | Path | Description |
|--------|------|-------------|
| POST | `/openai/deployments/{deployment_id}/chat/completions` | Chat completions proxy |
| POST | `/openai/deployments/{deployment_id}/embeddings` | Embeddings proxy |

### Azure Speech
| Method | Path | Description |
|--------|------|-------------|
| POST | `/speech/recognition/conversation/cognitiveservices/v1` | Real-time STT |
| POST | `/speechtotext/v3.1/transcriptions` | Create batch transcription |
| GET | `/speechtotext/v3.1/transcriptions/{id}` | Get transcription status |
| GET | `/speechtotext/v3.1/transcriptions/{id}/files` | Get transcription files |
| DELETE | `/speechtotext/v3.1/transcriptions/{id}` | Delete transcription |

### Health
| Method | Path | Description |
|--------|------|-------------|
| GET | `/health` | Liveness probe |
| GET | `/health/ready` | Readiness probe |

## Authentication

All endpoints (except `/health` and `/docs`) require a valid Microsoft Entra ID Bearer token:

```
Authorization: Bearer <token>
```

The gateway validates:
- Token signature (against Entra ID JWKS)
- Issuer (`iss`)
- Audience (`aud`)
- Expiration (`exp`)

Consumer identity is extracted from the `azp` claim for auditing.

## Configuration

All configuration is externalized via environment variables, injected through Kubernetes ConfigMaps and Secrets:

### ConfigMap Values (non-sensitive)
| Variable | Description | Example |
|----------|-------------|---------|
| `AZURE_OPENAI_ENDPOINT` | Azure OpenAI resource URL | `https://myresource.openai.azure.com` |
| `AZURE_OPENAI_API_VERSION` | API version | `2024-02-01` |
| `AZURE_SPEECH_ENDPOINT` | Azure Speech service URL | `https://westeurope.api.cognitive.microsoft.com` |
| `AZURE_SPEECH_REGION` | Azure Speech region | `westeurope` |
| `LANGFUSE_HOST` | Langfuse instance URL | `https://langfuse.example.com` |
| `ENTRA_TENANT_ID` | Entra ID tenant | `xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx` |
| `ENTRA_CLIENT_ID` | Expected token audience | `xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx` |
| `ENVIRONMENT` | Deployment environment | `DEV` / `PRE` / `PRO` |

### Secret Values (sensitive)
| Variable | Description |
|----------|-------------|
| `AZURE_OPENAI_API_KEY` | Azure OpenAI API key |
| `AZURE_SPEECH_API_KEY` | Azure Speech subscription key |
| `LANGFUSE_PUBLIC_KEY` | Langfuse public key |
| `LANGFUSE_SECRET_KEY` | Langfuse secret key |

## Environments

| Environment | Helm Values | Replicas | Notes |
|-------------|-------------|----------|-------|
| DEV (cert) | `values-cert.yaml` | 1 | `pullPolicy: Always` for SNAPSHOT images |
| PRE | `values-pre.yaml` | 1 | Pre-production validation |
| PRO | `values-pro.yaml` | 2 | Production with increased resources |

## Auditing (Langfuse)

Every API call generates a Langfuse trace with:
- **Consumer identity** (from Entra ID `azp` claim)
- **Full request/response payloads** (JSON bodies; audio logged as metadata)
- **Latency** (start-to-end duration in milliseconds)
- **Token usage** (prompt_tokens, completion_tokens, total_tokens for OpenAI calls)
- **Error details** (status codes, error messages)
- **Environment tag** (DEV/PRE/PRO)
- **Model/deployment info**

Auditing is non-blocking — Langfuse failures do not impact request processing.

## Resilience

- **Retry**: Automatic retry on transient errors (429, 500, 502, 503, 504) with exponential backoff
- **Backoff**: Initial 1s, max 10s, max 3 attempts
- **Retry-After**: Respects Azure's `Retry-After` header
- **Timeouts**: 60s for OpenAI, 120s for Speech
- **Error format**: RFC 7807 Problem Details

## Required Permissions

### Azure
- Azure OpenAI resource: `Cognitive Services OpenAI User` role
- Azure Speech resource: `Cognitive Services Speech User` role

### Entra ID
- App Registration with configured audience (`ENTRA_CLIENT_ID`)
- Token validation requires access to Entra ID JWKS endpoint

### Kubernetes
- ConfigMap `cm-gateway-api` with non-sensitive config
- Secret `secret-gateway-api` with API keys and Langfuse credentials
- Ingress/Route configured for external access

### Langfuse
- Project with public/secret key pair for trace ingestion

## Development

### Run locally
```bash
# Install dependencies
pip install pipenv==2023.12.1
pipenv install --dev

# Set environment variables (create .env file)
# Run application
pipenv run uvicorn app.main:app --host 0.0.0.0 --port 8080 --reload

# Run tests
pipenv run python -m pytest -v --cov=app --cov-report=term-missing
```

### Project Structure
```
├── app/
│   ├── main.py                  # FastAPI application entrypoint
│   ├── config.py                # Pydantic Settings configuration
│   ├── routers/
│   │   ├── health.py            # Health check endpoints
│   │   ├── openai.py            # Azure OpenAI proxy endpoints
│   │   └── speech.py            # Azure Speech proxy endpoints
│   ├── services/
│   │   └── azure_client.py      # Azure HTTP client with retry
│   ├── middleware/
│   │   ├── auth.py              # Entra ID token validation
│   │   ├── audit.py             # Langfuse auditing middleware
│   │   └── logging_middleware.py # Structured request logging
│   └── utils/
│       └── logging_config.py    # JSON logging configuration
├── tests/
│   ├── conftest.py              # Test fixtures and JWT helpers
│   ├── test_auth.py             # Authentication tests
│   ├── test_openai.py           # OpenAI proxy tests
│   ├── test_speech.py           # Speech proxy tests
│   ├── test_audit.py            # Langfuse audit tests
│   ├── test_config.py           # Configuration tests
│   └── test_health.py           # Health check tests
├── docs/
│   ├── GATEWAY_API.md           # This documentation
│   └── USER_STORIES.md          # User stories
├── .gluon/                      # CI/CD pipeline configuration
├── Dockerfile                   # Container image definition
├── Pipfile                      # Python dependencies
├── entrypoint.sh                # Container entrypoint
├── setup.py                     # Package metadata
└── pytest.ini                   # Test configuration
```
